"""tests for the diff parser. added lines only, skip deleted files."""
from __future__ import annotations

import textwrap

from app.analyzers.diff_parser import parse_diff


def test_parses_added_lines_only():
    diff = textwrap.dedent("""\
        diff --git a/foo.py b/foo.py
        index aaaaaa..bbbbbb 100644
        --- a/foo.py
        +++ b/foo.py
        @@ -1,3 +1,5 @@
         import os
        +import sys
        +
         def f():
             return 1
    """)

    files = parse_diff(diff)
    assert len(files) == 1
    assert files[0].path == "foo.py"
    assert files[0].is_python is True
    assert files[0].changed_lines == {2, 3}


def test_skips_non_python_flag():
    diff = textwrap.dedent("""\
        diff --git a/README.md b/README.md
        index aaaaaa..bbbbbb 100644
        --- a/README.md
        +++ b/README.md
        @@ -1,1 +1,2 @@
         hello
        +world
    """)

    assert parse_diff(diff)[0].is_python is False


def test_deleted_file_is_skipped():
    diff = textwrap.dedent("""\
        diff --git a/gone.py b/gone.py
        deleted file mode 100644
        index aaaaaa..0000000
        --- a/gone.py
        +++ /dev/null
        @@ -1,2 +0,0 @@
        -x = 1
        -y = 2
    """)

    assert parse_diff(diff) == []
