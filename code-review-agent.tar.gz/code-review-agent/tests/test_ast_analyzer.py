"""tests for the AST analyzer. mostly pinning line ranges and complexity math."""
from __future__ import annotations

import textwrap

from app.analyzers.ast_analyzer import analyze, functions_touched_by_lines


def test_extracts_top_level_functions():
    src = textwrap.dedent("""
        def add(a, b):
            return a + b

        def sub(a, b):
            return a - b
    """).strip()

    fns = analyze(src)
    names = {f.name for f in fns}
    assert names == {"add", "sub"}


def test_extracts_methods_and_nested():
    src = textwrap.dedent("""
        class Foo:
            def method(self, x):
                def inner():
                    return 1
                return inner()
    """).strip()

    names = {f.name for f in analyze(src)}
    assert "method" in names
    assert "inner" in names


def test_signature_includes_defaults_and_return_type():
    src = textwrap.dedent("""
        def greet(name: str, greeting: str = "hi") -> str:
            return f"{greeting}, {name}"
    """).strip()

    fn = analyze(src)[0]
    assert fn.signature.startswith("def greet(")
    assert "greeting: str='hi'" in fn.signature or "greeting: str = 'hi'" in fn.signature
    assert fn.signature.endswith("-> str")


def test_async_signature():
    src = "async def fetch(url: str) -> dict:\n    return {}\n"
    assert analyze(src)[0].signature.startswith("async def fetch(")


def test_complexity_trivial_is_one():
    assert analyze("def f():\n    return 1\n")[0].complexity == 1


def test_complexity_counts_branches():
    src = textwrap.dedent("""
        def f(x, y):
            if x:
                if y:
                    return 1
            for i in range(x):
                if i > 0:
                    pass
            return 0
    """).strip()

    # 1 + 2 ifs + 1 for + 1 inner if = 5
    assert analyze(src)[0].complexity == 5


def test_complexity_counts_boolop_operands():
    src = textwrap.dedent("""
        def f(a, b, c):
            if a and b and c:
                return 1
            return 0
    """).strip()

    # 1 + if + 2 extra BoolOp operands = 4
    assert analyze(src)[0].complexity == 4


def test_complexity_counts_except_handlers():
    src = textwrap.dedent("""
        def f():
            try:
                x = 1
            except ValueError:
                pass
            except KeyError:
                pass
    """).strip()

    # 1 + 2 except = 3
    assert analyze(src)[0].complexity == 3


def test_line_ranges_are_accurate():
    src = textwrap.dedent("""
        def one():
            return 1


        def two():
            x = 2
            return x
    """).lstrip()

    fns = {f.name: f for f in analyze(src)}
    assert fns["one"].start_line == 1
    assert fns["one"].end_line == 2
    assert fns["two"].start_line == 5
    assert fns["two"].end_line == 7


def test_syntax_error_returns_empty_list():
    # must not crash the webhook handler
    assert analyze("def broken(:\n    pass") == []


def test_functions_touched_by_lines_filters_correctly():
    src = textwrap.dedent("""
        def touched():
            return 1


        def untouched():
            return 2
    """).lstrip()

    result = functions_touched_by_lines(analyze(src), {2})
    assert [f.name for f in result] == ["touched"]


def test_functions_touched_by_lines_empty_when_no_overlap():
    src = textwrap.dedent("""
        def a():
            return 1

        def b():
            return 2
    """).lstrip()

    assert functions_touched_by_lines(analyze(src), {100}) == []
