"""claude wrapper. tool_use forces structured output, range check drops bad line numbers."""
from __future__ import annotations

import json
import logging
from typing import Any

from anthropic import Anthropic

from app.config import settings
from app.schemas import FunctionInfo, ReviewFinding, ReviewOutput

log = logging.getLogger(__name__)


REVIEW_TOOL: dict[str, Any] = {
    "name": "submit_review",
    "description": (
        "Submit inline code review findings. Call this exactly once with every "
        "finding you want posted on the pull request. If the code has no issues, "
        "call it with an empty `findings` array."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "findings": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "function_name": {
                            "type": "string",
                            "description": "Name of the function the finding is about. Must match one of the functions provided in context.",
                        },
                        "line": {
                            "type": "integer",
                            "description": "Line number in the new file version. Must fall within the function's declared line range.",
                        },
                        "severity": {
                            "type": "string",
                            "enum": ["low", "medium", "high"],
                        },
                        "category": {
                            "type": "string",
                            "enum": ["bug", "security", "perf", "style", "maintainability"],
                        },
                        "comment": {
                            "type": "string",
                            "description": "One concrete, actionable review comment. No pleasantries.",
                        },
                    },
                    "required": ["function_name", "line", "severity", "category", "comment"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["findings"],
        "additionalProperties": False,
    },
}


SYSTEM_PROMPT = """You are a senior Python code reviewer. You review ONLY the functions you are given, and you are strict about staying within their line ranges.

Rules:
- Only flag real issues. Skip anything subjective or stylistic that a linter would catch.
- Every finding's `line` MUST be an integer inside the function's declared start_line..end_line range. Never invent line numbers.
- `function_name` MUST exactly match one of the function names in the context.
- Prefer high-signal comments: bugs, security, performance cliffs, and maintainability traps that will bite someone later.
- If a function is fine, don't force a finding. Empty findings lists are valid and expected.
"""


def _build_user_message(file_path: str, functions: list[FunctionInfo]) -> str:
    blocks = []
    for fn in functions:
        blocks.append(
            f"### Function: `{fn.name}`\n"
            f"- File: `{file_path}`\n"
            f"- Signature: `{fn.signature}`\n"
            f"- Line range: {fn.start_line}..{fn.end_line}\n"
            f"- Cyclomatic complexity: {fn.complexity}\n\n"
            f"```python\n{fn.source}\n```\n"
        )
    body = "\n".join(blocks)
    return (
        f"Review the following functions from `{file_path}`. "
        f"Use the `submit_review` tool. Remember: every `line` you return must fall "
        f"inside the function's line range shown above.\n\n{body}"
    )


def _extract_tool_input(response: Any) -> dict[str, Any] | None:
    for block in response.content:
        if getattr(block, "type", None) == "tool_use" and block.name == "submit_review":
            return block.input
    return None


def review_functions(file_path: str, functions: list[FunctionInfo]) -> list[ReviewFinding]:
    """send one batch to claude, return validated findings."""
    if not functions:
        return []

    client = Anthropic(api_key=settings.anthropic_api_key)

    response = client.messages.create(
        model=settings.claude_model,
        max_tokens=4096,
        system=SYSTEM_PROMPT,
        tools=[REVIEW_TOOL],
        tool_choice={"type": "tool", "name": "submit_review"},
        messages=[{"role": "user", "content": _build_user_message(file_path, functions)}],
    )

    raw = _extract_tool_input(response)
    if raw is None:
        log.warning("claude didn't call submit_review. content: %s", response.content)
        return []

    try:
        parsed = ReviewOutput.model_validate(raw)
    except Exception:
        log.exception("schema validation failed: %s", json.dumps(raw)[:500])
        return []

    # range check: schema alone doesn't know per-func ranges, so enforce here.
    # this is what stops hallucinated line numbers from reaching github.
    by_name = {f.name: f for f in functions}
    valid: list[ReviewFinding] = []
    for finding in parsed.findings:
        fn = by_name.get(finding.function_name)
        if fn is None:
            log.warning("dropped: unknown function %s", finding.function_name)
            continue
        if not (fn.start_line <= finding.line <= fn.end_line):
            log.warning(
                "dropped: %s line %d outside %d..%d",
                finding.function_name, finding.line, fn.start_line, fn.end_line,
            )
            continue
        valid.append(finding)

    return valid
