"""minimal github rest client: fetch PR diff, fetch file at commit, post inline review comments."""
from __future__ import annotations

import base64
import logging
from dataclasses import dataclass

import httpx

from app.config import settings

log = logging.getLogger(__name__)

GITHUB_API = "https://api.github.com"


@dataclass
class PullRequestRef:
    owner: str
    repo: str
    number: int
    head_sha: str

    @property
    def full_name(self) -> str:
        return f"{self.owner}/{self.repo}"


def _headers(accept: str = "application/vnd.github+json") -> dict[str, str]:
    return {
        "Authorization": f"Bearer {settings.github_token}",
        "Accept": accept,
        "X-GitHub-Api-Version": "2022-11-28",
    }


async def fetch_pr_diff(pr: PullRequestRef) -> str:
    url = f"{GITHUB_API}/repos/{pr.full_name}/pulls/{pr.number}"
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(url, headers=_headers("application/vnd.github.v3.diff"))
        r.raise_for_status()
        return r.text


async def fetch_file_at_commit(pr: PullRequestRef, path: str, ref: str) -> str | None:
    """None for missing or non-utf8 files."""
    url = f"{GITHUB_API}/repos/{pr.full_name}/contents/{path}"
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(url, headers=_headers(), params={"ref": ref})
        if r.status_code == 404:
            return None
        r.raise_for_status()
        data = r.json()

    if data.get("encoding") != "base64":
        return None
    try:
        return base64.b64decode(data["content"]).decode("utf-8")
    except (UnicodeDecodeError, ValueError):
        return None


async def post_review_comment(
    pr: PullRequestRef,
    path: str,
    line: int,
    body: str,
) -> int | None:
    """post one inline comment. returns github id or None on failure."""
    url = f"{GITHUB_API}/repos/{pr.full_name}/pulls/{pr.number}/comments"
    payload = {
        "body": body,
        "commit_id": pr.head_sha,
        "path": path,
        "line": line,
        "side": "RIGHT",  # comment on the new version
    }
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(url, headers=_headers(), json=payload)

    if r.status_code >= 300:
        # common cause: line isn't in the PR diff. log and skip, don't fail the whole review.
        log.warning("post failed %s:%d -> %d %s", path, line, r.status_code, r.text[:200])
        return None
    return r.json().get("id")
