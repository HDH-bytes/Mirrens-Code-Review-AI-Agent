"""orchestrator: PR -> diff -> AST -> claude -> github comments -> postgres."""
from __future__ import annotations

import asyncio
import logging

from app.analyzers import analyze, functions_touched_by_lines, parse_diff
from app.config import settings
from app.db import get_session
from app.db.repository import (
    get_or_create_repository,
    get_or_create_review,
    mark_review_completed,
    mark_review_failed,
    record_comment,
    recurring_violations,
)
from app.schemas import ReviewFinding
from app.services import claude_client, github_client
from app.services.github_client import PullRequestRef

log = logging.getLogger(__name__)

_SEVERITY_RANK = {"low": 0, "medium": 1, "high": 2}


def _severity_ge(finding: str, threshold: str) -> bool:
    return _SEVERITY_RANK[finding] >= _SEVERITY_RANK[threshold]


def _format_comment_body(finding: ReviewFinding, prior_hits: int) -> str:
    header = f"**[{finding.severity.upper()} · {finding.category}]**"
    body = f"{header} {finding.comment}"
    if prior_hits > 0:
        body += (
            f"\n\n_Note: `{finding.category}` issues have been flagged on "
            f"`{finding.function_name}` {prior_hits} time(s) before in this repo._"
        )
    return body


async def review_pr(pr: PullRequestRef) -> int:
    """full review pass. returns comments posted."""
    comments_posted = 0

    with get_session() as session:
        repo = get_or_create_repository(session, pr.full_name)
        review = get_or_create_review(session, repo, pr.number, pr.head_sha)

        if not repo.enabled:
            log.info("repo %s disabled, skipping", pr.full_name)
            mark_review_completed(session, review, 0)
            return 0

        # idempotency: same head sha already reviewed -> bail
        if review.status == "completed":
            log.info("already reviewed %s#%d@%s", pr.full_name, pr.number, pr.head_sha[:7])
            return review.comments_posted

        min_severity = repo.min_severity
        disabled = set(repo.disabled_categories or [])
        repo_id = repo.id

    try:
        diff_text = await github_client.fetch_pr_diff(pr)
        file_diffs = [fd for fd in parse_diff(diff_text) if fd.is_python and fd.changed_lines]

        log.info("PR %s#%d: %d python file(s) changed", pr.full_name, pr.number, len(file_diffs))

        for fd in file_diffs:
            source = await github_client.fetch_file_at_commit(pr, fd.path, pr.head_sha)
            if source is None:
                continue

            functions = analyze(source)
            touched = functions_touched_by_lines(functions, fd.changed_lines)
            if not touched:
                continue

            # cap per-review to protect the token budget
            if len(touched) > settings.max_functions_per_review:
                log.info("capping %s: %d -> %d", fd.path, len(touched), settings.max_functions_per_review)
                touched = touched[: settings.max_functions_per_review]

            findings = claude_client.review_functions(fd.path, touched)

            for finding in findings:
                if finding.category in disabled:
                    continue
                if not _severity_ge(finding.severity, min_severity):
                    continue

                with get_session() as session:
                    repo_obj = session.get(type(repo), repo_id)
                    prior = recurring_violations(
                        session, repo_obj, finding.function_name, finding.category
                    )

                body = _format_comment_body(finding, prior)
                github_id = await github_client.post_review_comment(
                    pr, fd.path, finding.line, body
                )

                with get_session() as session:
                    review_obj = get_or_create_review(
                        session,
                        get_or_create_repository(session, pr.full_name),
                        pr.number,
                        pr.head_sha,
                    )
                    record_comment(
                        session,
                        review_obj,
                        fd.path,
                        finding.function_name,
                        finding.line,
                        finding.severity,
                        finding.category,
                        body,
                        github_id,
                    )

                if github_id is not None:
                    comments_posted += 1

        with get_session() as session:
            review_obj = get_or_create_review(
                session,
                get_or_create_repository(session, pr.full_name),
                pr.number,
                pr.head_sha,
            )
            mark_review_completed(session, review_obj, comments_posted)

        log.info("PR %s#%d: posted %d comment(s)", pr.full_name, pr.number, comments_posted)
        return comments_posted

    except Exception as exc:
        log.exception("review failed %s#%d", pr.full_name, pr.number)
        with get_session() as session:
            review_obj = get_or_create_review(
                session,
                get_or_create_repository(session, pr.full_name),
                pr.number,
                pr.head_sha,
            )
            mark_review_failed(session, review_obj, str(exc))
        raise


def review_pr_sync(pr: PullRequestRef) -> int:
    """sync wrapper for BackgroundTasks."""
    return asyncio.run(review_pr(pr))
