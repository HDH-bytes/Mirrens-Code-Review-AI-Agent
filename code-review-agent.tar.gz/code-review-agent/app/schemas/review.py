from typing import Literal
from pydantic import BaseModel, Field


Severity = Literal["low", "medium", "high"]
Category = Literal["bug", "security", "perf", "style", "maintainability"]


class FunctionInfo(BaseModel):
    """what we extract from the AST before sending to claude."""
    name: str
    signature: str
    start_line: int
    end_line: int
    complexity: int
    docstring: str | None = None
    source: str


class ReviewFinding(BaseModel):
    """one inline comment. mirrors the tool_use schema."""
    function_name: str
    line: int = Field(..., description="Line number in the NEW file version")
    severity: Severity
    category: Category
    comment: str


class ReviewOutput(BaseModel):
    findings: list[ReviewFinding]
