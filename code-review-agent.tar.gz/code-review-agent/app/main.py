"""fastapi webhook server. verifies HMAC sig, queues review in background."""
from __future__ import annotations

import hashlib
import hmac
import logging

from fastapi import BackgroundTasks, FastAPI, Header, HTTPException, Request

from app.config import settings
from app.services.github_client import PullRequestRef
from app.services.reviewer import review_pr_sync

logging.basicConfig(level=settings.log_level)
log = logging.getLogger(__name__)

app = FastAPI(title="AI Code Review Agent")


def _verify_signature(body: bytes, signature_header: str | None) -> None:
    """github sends `sha256=<hex>`. compare in constant time."""
    if not settings.github_webhook_secret:
        raise HTTPException(status_code=500, detail="Webhook secret not configured")
    if not signature_header or not signature_header.startswith("sha256="):
        raise HTTPException(status_code=401, detail="Missing or malformed signature")

    expected = hmac.new(
        settings.github_webhook_secret.encode(),
        body,
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(expected, signature_header.removeprefix("sha256=")):
        raise HTTPException(status_code=401, detail="Invalid signature")


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/webhooks/github")
async def github_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    x_github_event: str = Header(default=""),
    x_hub_signature_256: str | None = Header(default=None),
) -> dict[str, str]:
    body = await request.body()
    _verify_signature(body, x_hub_signature_256)

    if x_github_event == "ping":
        return {"status": "pong"}

    if x_github_event != "pull_request":
        return {"status": "ignored", "event": x_github_event}

    payload = await request.json()
    action = payload.get("action")
    # only act on events where head sha is new or freshly open
    if action not in {"opened", "synchronize", "reopened"}:
        return {"status": "ignored", "action": action or "unknown"}

    pr_data = payload["pull_request"]
    repo_data = payload["repository"]

    pr = PullRequestRef(
        owner=repo_data["owner"]["login"],
        repo=repo_data["name"],
        number=pr_data["number"],
        head_sha=pr_data["head"]["sha"],
    )

    # ack fast, run the review in the background (github retries if we take >10s)
    background_tasks.add_task(review_pr_sync, pr)
    return {"status": "queued", "pr": f"{pr.full_name}#{pr.number}"}
