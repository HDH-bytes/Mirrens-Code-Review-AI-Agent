"""query helpers. keeps the reviewer service readable."""
from __future__ import annotations

from datetime import datetime, timezone
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.db.models import Repository, Review, ReviewComment


def get_or_create_repository(session: Session, full_name: str) -> Repository:
    repo = session.execute(
        select(Repository).where(Repository.full_name == full_name)
    ).scalar_one_or_none()
    if repo is None:
        repo = Repository(full_name=full_name)
        session.add(repo)
        session.flush()
    return repo


def get_or_create_review(
    session: Session, repo: Repository, pr_number: int, head_sha: str
) -> Review:
    review = session.execute(
        select(Review).where(
            Review.repository_id == repo.id,
            Review.pr_number == pr_number,
            Review.head_sha == head_sha,
        )
    ).scalar_one_or_none()
    if review is None:
        review = Review(repository_id=repo.id, pr_number=pr_number, head_sha=head_sha)
        session.add(review)
        session.flush()
    return review


def record_comment(
    session: Session,
    review: Review,
    file_path: str,
    function_name: str,
    line: int,
    severity: str,
    category: str,
    body: str,
    github_comment_id: int | None,
) -> None:
    session.add(
        ReviewComment(
            review_id=review.id,
            file_path=file_path,
            function_name=function_name,
            line=line,
            severity=severity,
            category=category,
            body=body,
            github_comment_id=github_comment_id,
        )
    )


def mark_review_completed(session: Session, review: Review, comments_posted: int) -> None:
    review.status = "completed"
    review.comments_posted = comments_posted
    review.completed_at = datetime.now(timezone.utc)


def mark_review_failed(session: Session, review: Review, error: str) -> None:
    review.status = "failed"
    review.error = error[:2000]
    review.completed_at = datetime.now(timezone.utc)


def recurring_violations(
    session: Session, repo: Repository, function_name: str, category: str
) -> int:
    """count past comments on the same (func, category) in this repo. drives regression notes."""
    stmt = (
        select(func.count(ReviewComment.id))
        .join(Review, Review.id == ReviewComment.review_id)
        .where(
            Review.repository_id == repo.id,
            ReviewComment.function_name == function_name,
            ReviewComment.category == category,
        )
    )
    return session.execute(stmt).scalar_one()
