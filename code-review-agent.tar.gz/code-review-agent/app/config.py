from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql://postgres:postgres@localhost:5433/code_review"

    anthropic_api_key: str = ""
    claude_model: str = "claude-sonnet-4-5"

    github_token: str = ""
    github_webhook_secret: str = ""

    log_level: str = "INFO"
    max_functions_per_review: int = 20


settings = Settings()
