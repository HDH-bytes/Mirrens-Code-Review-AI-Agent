"""unified diff -> set of changed line numbers per file (new-side only)."""
from __future__ import annotations

from dataclasses import dataclass

from unidiff import PatchSet


@dataclass
class FileDiff:
    path: str
    changed_lines: set[int]
    is_python: bool


def parse_diff(diff_text: str) -> list[FileDiff]:
    patch = PatchSet(diff_text)
    out: list[FileDiff] = []

    for pfile in patch:
        if pfile.is_removed_file:
            continue

        # strip github's `b/` prefix
        path = pfile.target_file
        if path.startswith("b/"):
            path = path[2:]

        changed: set[int] = set()
        for hunk in pfile:
            for line in hunk:
                # target_line_no is None for removed lines
                if line.is_added and line.target_line_no is not None:
                    changed.add(line.target_line_no)

        out.append(FileDiff(
            path=path,
            changed_lines=changed,
            is_python=path.endswith(".py"),
        ))

    return out
