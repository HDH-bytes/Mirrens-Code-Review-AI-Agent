"""AST -> per-function metadata. line ranges are the anchor we validate claude's findings against."""
from __future__ import annotations

import ast
from typing import Iterator

from app.schemas import FunctionInfo


# branching nodes for mccabe complexity
_BRANCHING_NODES = (
    ast.If,
    ast.For,
    ast.AsyncFor,
    ast.While,
    ast.ExceptHandler,
    ast.With,
    ast.AsyncWith,
    ast.Assert,
    ast.IfExp,
    ast.comprehension,
)


def _cyclomatic_complexity(node: ast.AST) -> int:
    """mccabe: 1 + count of branches."""
    complexity = 1
    for child in ast.walk(node):
        if isinstance(child, _BRANCHING_NODES):
            complexity += 1
        elif isinstance(child, ast.BoolOp):
            # `a and b and c` = 2 extra paths
            complexity += max(0, len(child.values) - 1)
        elif isinstance(child, ast.Match):
            complexity += len(child.cases)
    return complexity


def _format_signature(func: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """pretty signature via ast.unparse."""
    args = ast.unparse(func.args)
    returns = f" -> {ast.unparse(func.returns)}" if func.returns else ""
    prefix = "async def" if isinstance(func, ast.AsyncFunctionDef) else "def"
    return f"{prefix} {func.name}({args}){returns}"


def _iter_functions(tree: ast.AST) -> Iterator[ast.FunctionDef | ast.AsyncFunctionDef]:
    """all func defs: top-level, methods, nested."""
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            yield node


def analyze(source: str) -> list[FunctionInfo]:
    """parse -> FunctionInfo list. empty on syntax error so broken PRs don't crash the webhook."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    source_lines = source.splitlines()
    results: list[FunctionInfo] = []

    for func in _iter_functions(tree):
        start = func.lineno
        end = getattr(func, "end_lineno", None) or max(
            (getattr(c, "end_lineno", start) or start) for c in ast.walk(func)
        )

        func_source = "\n".join(source_lines[start - 1:end])

        results.append(
            FunctionInfo(
                name=func.name,
                signature=_format_signature(func),
                start_line=start,
                end_line=end,
                complexity=_cyclomatic_complexity(func),
                docstring=ast.get_docstring(func),
                source=func_source,
            )
        )

    return results


def functions_touched_by_lines(
    functions: list[FunctionInfo], changed_lines: set[int]
) -> list[FunctionInfo]:
    """only funcs whose range overlaps changed lines."""
    return [
        f for f in functions
        if any(f.start_line <= ln <= f.end_line for ln in changed_lines)
    ]
