"""local runner: full pipeline minus github. useful for smoke testing before wiring webhooks.

usage:
    python scripts/test_review_locally.py sample_prs/example.py sample_prs/example.diff
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.analyzers import analyze, functions_touched_by_lines, parse_diff
from app.services import claude_client


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_file", help="new version of the .py file")
    parser.add_argument("diff_file", help="unified diff")
    parser.add_argument("--repo-path", default=None,
                        help="path shown to claude (defaults to source filename)")
    args = parser.parse_args()

    source_path = Path(args.source_file)
    diff_path = Path(args.diff_file)
    repo_path = args.repo_path or source_path.name

    source = source_path.read_text()
    diff_text = diff_path.read_text()

    file_diffs = parse_diff(diff_text)
    target = next((fd for fd in file_diffs if fd.path.endswith(source_path.name)), None)
    if target is None:
        print(f"[!] diff has no changes to {source_path.name}")
        print(f"    files in diff: {[fd.path for fd in file_diffs]}")
        return 1

    print(f"[*] changed lines: {sorted(target.changed_lines)}")

    functions = analyze(source)
    print(f"[*] {len(functions)} function(s):")
    for fn in functions:
        print(f"      - {fn.signature}  (lines {fn.start_line}-{fn.end_line}, cc={fn.complexity})")

    touched = functions_touched_by_lines(functions, target.changed_lines)
    print(f"[*] {len(touched)} touched by diff: {[fn.name for fn in touched]}")

    if not touched:
        return 0

    print("[*] sending to claude...")
    findings = claude_client.review_functions(repo_path, touched)

    print(f"\n[=] {len(findings)} finding(s):\n")
    for i, f in enumerate(findings, 1):
        print(f"--- {i} ---")
        print(f"  func:     {f.function_name}")
        print(f"  line:     {f.line}")
        print(f"  severity: {f.severity}")
        print(f"  category: {f.category}")
        print(f"  comment:  {f.comment}")
        print()

    print("[*] json:")
    print(json.dumps([f.model_dump() for f in findings], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
