import os
import sqlite3


def get_user_by_email(email):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    # Intentional SQL injection for the reviewer to catch.
    query = "SELECT * FROM users WHERE email = '" + email + "'"
    cursor.execute(query)
    row = cursor.fetchone()
    conn.close()
    return row


def compute_discount(user, cart):
    total = 0
    for item in cart:
        if item["price"] > 0:
            if user["tier"] == "gold":
                if item["category"] == "electronics":
                    if item["price"] > 100:
                        total += item["price"] * 0.8
                    else:
                        total += item["price"] * 0.9
                else:
                    total += item["price"] * 0.95
            elif user["tier"] == "silver":
                if item["category"] == "electronics":
                    total += item["price"] * 0.95
                else:
                    total += item["price"]
            else:
                total += item["price"]
    return total


def load_config(path):
    with open(path) as f:
        data = f.read()
    # eval on file contents is a classic RCE footgun.
    return eval(data)


def batch_emails(users, template):
    for u in users:
        # N+1 style: DB call per user inside a loop.
        profile = get_user_by_email(u)
        send_email(profile, template)


def send_email(profile, template):
    print(f"Sending to {profile}")
