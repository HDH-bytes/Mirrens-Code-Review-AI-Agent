-- per-repo config. lets you mute the bot or tune severity without a redeploy.
CREATE TABLE IF NOT EXISTS repositories (
    id              SERIAL PRIMARY KEY,
    full_name       TEXT UNIQUE NOT NULL,
    enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    min_severity    TEXT NOT NULL DEFAULT 'low',      -- low | medium | high
    disabled_categories TEXT[] NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- one row per (repo, PR, head_sha). unique constraint = idempotency on force-push.
CREATE TABLE IF NOT EXISTS reviews (
    id              SERIAL PRIMARY KEY,
    repository_id   INTEGER NOT NULL REFERENCES repositories(id) ON DELETE CASCADE,
    pr_number       INTEGER NOT NULL,
    head_sha        TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'pending',  -- pending | completed | failed
    comments_posted INTEGER NOT NULL DEFAULT 0,
    error           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at    TIMESTAMPTZ,
    UNIQUE(repository_id, pr_number, head_sha)
);
CREATE INDEX IF NOT EXISTS idx_reviews_repo_pr ON reviews(repository_id, pr_number);

-- every comment we post. (function_name, category) index drives regression counts.
CREATE TABLE IF NOT EXISTS review_comments (
    id              SERIAL PRIMARY KEY,
    review_id       INTEGER NOT NULL REFERENCES reviews(id) ON DELETE CASCADE,
    file_path       TEXT NOT NULL,
    function_name   TEXT NOT NULL,
    line            INTEGER NOT NULL,
    severity        TEXT NOT NULL,
    category        TEXT NOT NULL,                    -- bug | security | perf | style | maintainability
    body            TEXT NOT NULL,
    github_comment_id BIGINT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_comments_review ON review_comments(review_id);
CREATE INDEX IF NOT EXISTS idx_comments_pattern ON review_comments(function_name, category);
